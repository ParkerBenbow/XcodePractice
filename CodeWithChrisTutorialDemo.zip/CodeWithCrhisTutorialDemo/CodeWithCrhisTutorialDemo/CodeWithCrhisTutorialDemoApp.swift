//
//  CodeWithCrhisTutorialDemoApp.swift
//  CodeWithCrhisTutorialDemo
//
//  Created by PARKER BENBOW on 1/23/23.
//

import SwiftUI

@main
struct CodeWithCrhisTutorialDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
